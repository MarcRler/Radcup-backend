# radcup app
bitte die startRadcup.sh ausführen und entsprechend auswählen. Es kann sein,dass die Option 6 (starten von Radcup) einen Fehler wirft wenn ein docker image nicht geladen werden konnte. Bitte dann nochmals testen. Teilweiße hatten wir Probleme im Eduroam Netzwerk, zuhause hat es funktioniert. 
Generell wurde die App auf MACOSX, Linux Mint(Debian) und Fedora(RHEL) getestet. Windows funktioniert leider nicht. Es muss Docker und Docker Compose vorhanden sein. 
Die Docktrip muss im Quelltext durch das startRadup.sh Skript angepasst werden durch Option 1-3. Option 4 funktioniert nur wenn nicht Option 6 noch läuft - starten der Tests, leider ist der Output ein wenig unübersichtlich durch den Docker-compose output. 
Option 99 (Devmode) wurde von uns für die Entwicklung genutzt und kann ignoriert werden. 

Sollten Fragen aufkommen zum starten der APP bitte an ih027 wenden.
Viel Spaß bei Radcup. 
