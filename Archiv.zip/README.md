# radcup app
bitte die startRadcup.sh ausführen und entsprechend auswählen.
